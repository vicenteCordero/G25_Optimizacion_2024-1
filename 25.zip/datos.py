data_dict = {   
    "costos_por_tipo": {
        "1": 197990,
        "2": 756990,
        "3": 6300000
    },
    "energia_por_tipo": {
        "1": 3,
        "2": 25,
        "3": 125
    },
    "satisfaccion": {
        "1": 200,
        "2": 2000,
        "3": 8000
    },
    "cantidad_estacionamientos": 100,
    "presupuesto": 93845000,
    "energia_total_edificio": 1000,
    "carga_estandar": 0.75,
    "carga_maxima": 0.8,
    "capacidad_potencia_media": 30,
    "carga_media": 0.5
}